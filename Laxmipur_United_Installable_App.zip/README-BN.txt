LAXMIPUR UNITED — INSTALLABLE WEB APP

এই ZIP ফাইলটি একটি installable web app (PWA) প্যাকেজ। এটি সরাসরি Android APK নয়।

ইনস্টল করার নিয়ম:
1. ZIP ফাইলটি Extract করুন।
2. index.html ও বাকি ফাইলগুলো HTTPS সমর্থিত কোনো static hosting-এ আপলোড করুন।
   উদাহরণ: GitHub Pages, Netlify বা আপনার নিজস্ব hosting।
3. আপলোড করা ওয়েবসাইটটি Android Chrome-এ খুলুন।
4. Chrome-এর ⋮ মেনু থেকে "Install app" অথবা "Add to Home screen" চাপুন।
5. Laxmipur United অ্যাপটি ফোনের Home Screen-এ যুক্ত হবে।

গুরুত্বপূর্ণ:
- PWA install করতে HTTPS hosting প্রয়োজন; শুধু ফোনে index.html ফাইল খুললে install option নাও আসতে পারে।
- অ্যাপের মূল HTML-এ ২৪টি player card, club branding এবং stadium hero background অন্তর্ভুক্ত।
- প্রথমবার অনলাইনে খুললে অ্যাপটি প্রয়োজনীয় ফাইল cache করে রাখবে।
